const express = require("express");
const app = express();
const path = require("path");
const ejs = require("ejs");
const bodyParser = require("body-parser");
const session = require("express-session");
const conexao = require("./config/database");
const bcrypt = require("bcrypt");
const saltRounds = 10;
require('dotenv').config();
const Eleitor = require("./model/Eleitor");
const Candidato = require("./model/Candidato");
const Administrador = require("./model/Administrador");
const Voto = require("./model/Voto");

app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
  })
);

app.use((req, res, next) => {
    if (req.session && req.session.tipoAcesso) {
        
        let linkHome = '/';
        
        switch (req.session.tipoAcesso) {
            case 'Eleitor':
                linkHome = '/home_eleitor';
                break;
            case 'Candidato':
                linkHome = '/home_candidato';
                break;
            case 'Administrador':
                linkHome = '/home_adm';
                break;
        }

        res.locals.linkHome = linkHome; 
        res.locals.tipoAcesso = req.session.tipoAcesso;
    } else {
        res.locals.linkHome = '/login';
        res.locals.tipoAcesso = null;
    }
    
    next();
});

app.get("/", function (req, res) {
  res.render("home.ejs", {});
});

app.get("/cadastro", function (req, res) {
  res.render("cadastro.ejs", {});
});

app.get("/login", function (req, res) {
  if (req.session.id_usuario) {
      return res.redirect(res.locals.linkHome);
  }
  res.render("login.ejs", {});
});

app.post('/login', async (req, res) => {
  const { tipoLogin, cpf, senha } = req.body;

  try {
    let ModeloUsuario;
    
    switch (tipoLogin) {
      case 'Eleitor':
        ModeloUsuario = Eleitor;
        break;
      case 'Candidato':
        ModeloUsuario = Candidato;
        break;
      case 'Administrador':
        ModeloUsuario = Administrador;
        break;
      default:
        return res.send(
          `<script>alert("Tipo de acesso inválido."); window.history.back();</script>`
        );
    }

    const usuario = await ModeloUsuario.findOne({ cpf });

    if (!usuario) {
      return res.send(
        `<script>alert("Cadastro não encontrado para este ${tipoLogin}."); window.history.back();</script>`
      );
    }

    const match = await bcrypt.compare(senha, usuario.senha);

    if (match) {
      req.session.id_usuario = usuario._id;
      req.session.cpf = usuario.cpf;
      req.session.tipoAcesso = tipoLogin;
      
      switch (tipoLogin) {
        case 'Eleitor':
          return res.redirect("/home_eleitor");
        case 'Candidato':
          return res.redirect("/home_candidato");
        case 'Administrador':
          return res.redirect("/home_adm");
        default:
          return res.redirect("/"); 
      }
    } else {
      return res.send(
        `<script>alert("CPF ou senha incorretos."); window.history.back();</script>`
      );
    }
  } catch (error) {
    console.error(`Erro ao consultar o banco de dados (${tipoLogin}): `, error);
    return res.status(500).send(
      `<script>alert("Ocorreu um erro ao consultar o banco de dados."); window.history.back();</script>`
    );
  }
});

app.get("/sair", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error("Erro ao finalizar a sessão:", err);
      return res
        .status(500)
        .send(
          `<script>alert("Ocorreu um erro ao sair da conta."); window.history.back();</script>`
        );
    }
    res.redirect("/login");
  });
});

app.get("/urna", async function (req, res) {
    try {
        const idUsuario = req.session.id_usuario;
        const tipoAcesso = req.session.tipoAcesso;

        if (!idUsuario) {
            return res.status(401).send(
                `<script>alert("Acesso negado. Você precisa estar logado."); window.location.href="/login";</script>`
            );
        }

        if (tipoAcesso === 'Administrador') {
            return res.status(403).send(
                `<script>alert("Administradores não têm acesso à urna de votação."); window.history.back();</script>`
            );
        }

        let ModeloVotante;
        if (tipoAcesso === 'Eleitor') {
            ModeloVotante = Eleitor;
        } else if (tipoAcesso === 'Candidato') {
            ModeloVotante = Candidato;
        }

        const usuarioVotante = await ModeloVotante.findById(idUsuario);

        if (!usuarioVotante) {
            return res.status(404).send(
                `<script>alert("Usuário não encontrado."); window.location.href="/login";</script>`
            );
        }

        if (usuarioVotante.votou) {
            return res.send(`
                <script>
                    alert("Você já votou.");
                    window.location.href = "${res.locals.linkHome}";
                </script>
            `);
        }

        // A urna só carrega candidatos homologados E ativos
const docs = await Candidato.find({ 
    status: "Homologado", 
    ativo: true 
});
        res.render("urna.ejs", { Candidatos: docs });

    } catch (error) {
        console.error("Erro: ", error);
        res.status(500).send("Ocorreu um erro ao carregar os candidatos.");
    }
});

app.post("/votar", async (req, res) => {
    try {
        const idUsuario = req.session.id_usuario;
        const tipoAcesso = req.session.tipoAcesso;

        if (!idUsuario) {
            return res.status(401).json({ message: "Acesso negado. Você precisa estar logado para votar." });
        }

        if (tipoAcesso === 'Administrador') {
            return res.status(403).json({ message: "Administradores não votam." });
        }

        let ModeloVotante;
        if (tipoAcesso === 'Eleitor') {
            ModeloVotante = Eleitor;
        } else if (tipoAcesso === 'Candidato') {
            ModeloVotante = Candidato;
        }

        const usuarioVotante = await ModeloVotante.findById(idUsuario);

        if (!usuarioVotante) {
            return res.status(404).json({ message: "Usuário não encontrado no sistema." });
        }

        if (usuarioVotante.votou) {
            return res.status(400).json({ message: "Você já votou." });
        }

        const { deputadoEstadual, deputadoFederal, senador, governador, presidente } = req.body;

        async function validarCandidato(numero, cargo) {
            if (!numero) return null;
            const candidato = await Candidato.findOne({ numero, cargo, status: "Homologado" });
            return candidato ? candidato._id : null;
        }

        const voto = {
            deputadoEstadual: await validarCandidato(deputadoEstadual, "Deputado Estadual"),
            deputadoFederal: await validarCandidato(deputadoFederal, "Deputado Federal"),
            senador: await validarCandidato(senador, "Senador"),
            governador: await validarCandidato(governador, "Governador"),
            presidente: await validarCandidato(presidente, "Presidente")
        };

        await Voto.create({
            votos: voto
        });

        for (let cargo in voto) {
            if (voto[cargo]) {
                await Candidato.findByIdAndUpdate(voto[cargo], {
                    $inc: { votos: 1 }
                });
            }
        }

        usuarioVotante.votou = true;
        await usuarioVotante.save();

        res.json({ message: "Voto registrado com sucesso!" });

    } catch (error) {
        console.error("Erro ao processar votação:", error);
        res.status(500).json({ message: "Erro interno ao registrar voto." });
    }
});

app.get("/candidato", function (req, res) {
  res.render("candidato.ejs", {});
});

app.get("/admin", function (req, res) {
    try {
        const administradorId = req.session.id_usuario;

        if (!administradorId) {
            return res.status(401).json({ message: "Acesso negado. Você precisa estar logado para votar." });
        }

      Candidato.find({}).then(function (docs) {
        res.render("admin.ejs", { Candidatos: docs });
      });
    } catch (error) {
      console.error("Erro: ", error);
      res.status(500).send("Ocorreu um erro ao carregar os candidatos.");
    }
});

app.post("/admin/homologar", async (req, res) => {
    try {
        if (req.session.tipoAcesso !== 'Administrador') {
            return res.status(403).json({ message: "Acesso negado. Apenas administradores podem homologar." });
        }

        const { candidatoId, novoStatus } = req.body;

        if (!["Homologado", "Rejeitado"].includes(novoStatus)) {
            return res.status(400).json({ message: "Status inválido." });
        }

        await Candidato.findByIdAndUpdate(candidatoId, { status: novoStatus });

        res.json({ message: `Candidato ${novoStatus} com sucesso!` });

    } catch (error) {
        console.error("Erro ao atualizar status do candidato:", error);
        res.status(500).json({ message: "Erro interno ao processar a homologação." });
    }
});

app.get("/resultados", async (req, res) => {
  try {
    // A apuração só contabiliza os homologados E ativos
const candidatos = await Candidato.find({ 
    status: "Homologado", 
    ativo: true 
}).sort({ votos: -1 });

    const resultadosPorCargo = {};

    candidatos.forEach(candidato => {
      if (!resultadosPorCargo[candidato.cargo]) {
        resultadosPorCargo[candidato.cargo] = [];
      }
      resultadosPorCargo[candidato.cargo].push(candidato);
    });

    res.render("resultados.ejs", { resultadosPorCargo });

  } catch (error) {
    console.error("Erro ao carregar os resultados:", error);
    res.status(500).send("Erro interno ao carregar os resultados da eleição.");
  }
});

app.get("/cadastro_eleitor", function (req, res) {
  res.render("cadastro_eleitor.ejs", {});
});

app.post("/cadastro_eleitor", async (req, res) => {
    try {
        const { nome, cpf, dataNascimento, estado, cidade, senha } = req.body;

        const eleitorExistente = await Eleitor.findOne({ cpf: cpf });
        
        if (eleitorExistente) {
            return res.send(`
                <script>
                    alert('CPF já cadastrado! Verifique os dados.');
                    window.location.href = "/cadastro_eleitor";
                </script>
            `);
        }

        // Cálculo exato da idade
        const hoje = new Date();
        const nascimento = new Date(dataNascimento);
        let idadedecalculo = hoje.getFullYear() - nascimento.getFullYear();
        const m = hoje.getMonth() - nascimento.getMonth();
        if (m < 0 || (m === 0 && hoje.getDate() < nascimento.getDate())) {
            idadedecalculo--;
        }

        // REGRA DE NEGÓCIO: Idade mínima de 16 anos para eleitores
        if (idadedecalculo < 16) {
            return res.send(`
                <script>
                    alert('Cadastro não permitido! A idade mínima obrigatória ou facultativa para votar é de 16 anos completos.');
                    window.history.back();
                </script>
            `);
        }

        const hash = await bcrypt.hash(senha, saltRounds);

        const novoEleitor = new Eleitor({
            nome,
            cpf,
            dataNascimento,
            idade: idadedecalculo,
            estado,
            cidade,
            senha: hash
        });

        console.log("==== TESTE TAREFA 3: ELEITOR ====");
        console.log("Idade calculada salva no objeto:", novoEleitor.idade);

        await novoEleitor.save();

        res.send(`
            <script>
                alert('Eleitor cadastrado com sucesso! Agora você pode votar.');
                window.location.href = "/login";
            </script>
        `);
    } catch (error) {
        console.error("Erro no cadastro:", error);
        res.status(500).send("Erro ao cadastrar eleitor.");
    }
});

app.get("/cadastro_candidato", function (req, res) {
  res.render("cadastro_candidato.ejs", {});
});

app.post("/cadastro_candidato", async (req, res) => {
    try {
        const { nome, cpf, dataNascimento, estado, cidade, senha } = req.body;
        const existente = await Candidato.findOne({ $or: [{ cpf }] });
        if (existente) {
            return res.send("<script>alert('CPF já cadastrado!'); window.history.back();</script>");
        }

        const hoje = new Date();
        const nascimento = new Date(dataNascimento);
        let idadedecalculo = hoje.getFullYear() - nascimento.getFullYear();
        const m = hoje.getMonth() - nascimento.getMonth();
        if (m < 0 || (m === 0 && hoje.getDate() < nascimento.getDate())) {
            idadedecalculo--;
        }

        const hash = await bcrypt.hash(senha, saltRounds);

        const novoCandidato = new Candidato({
            nome,
            cpf,
            dataNascimento,
            idade: idadedecalculo,
            estado,
            cidade,
            senha: hash
        });
        
        await novoCandidato.save();
        res.send("<script>alert('Cadastro concluído! Faça login no portal para lançar sua candidatura.'); window.location.href = '/login';</script>");
    } catch (error) {
        console.error("ERRO GRAVE AO CADASTRAR:", error);
        // Agora o alerta vai te mostrar EXATAMENTE o que o banco recusou
        res.send(`<script>alert("Erro ao cadastrar: ${error.message}"); window.history.back();</script>`);
    }
});

app.get("/home_eleitor", (req, res) => res.render("home_eleitor.ejs"));

app.get("/home_candidato", (req, res) => res.render("home_candidato.ejs"));

app.get("/home_adm", (req, res) => res.render("home_adm.ejs"));

app.get("/lista_candidatos", async (req, res) => {
    try {
        // Mostra apenas candidatos homologados E ativos
const candidatos = await Candidato.find({ 
    status: "Homologado", 
    ativo: true 
}).sort({ nome: 1 });

        const candidatosPorCargo = {};
        candidatos.forEach(candidato => {
            if (!candidatosPorCargo[candidato.cargo]) {
                candidatosPorCargo[candidato.cargo] = [];
            }
            candidatosPorCargo[candidato.cargo].push(candidato);
        });

        res.render("lista_candidatos.ejs", { candidatosPorCargo });

    } catch (error) {
        console.error("Erro ao carregar candidatos:", error);
        res.status(500).send("Erro ao carregar a lista de candidatos.");
    }
});

app.get("/minha_candidatura", async (req, res) => {
    try {
        const idUsuario = req.session.id_usuario;

        if (!idUsuario || req.session.tipoAcesso !== 'Candidato') {
            return res.send(`<script>alert("Acesso negado."); window.location.href="/login";</script>`);
        }

        const candidato = await Candidato.findById(idUsuario);

        if (!candidato) {
            return res.send(`<script>alert("Candidato não encontrado."); window.location.href="/login";</script>`);
        }

        res.render("candidatura.ejs", { candidato });

    } catch (error) {
        console.error("Erro ao carregar candidatura:", error);
        res.status(500).send("Erro interno ao carregar a página.");
    }
});

app.post("/lancar_candidatura", async (req, res) => {
    try {
        const idUsuario = req.session.id_usuario;
        const { numero, cargo, partido, slogan, descricao } = req.body;

        // 1. Busca os dados do candidato para verificar a idade
        const candidato = await Candidato.findById(idUsuario);

        // 2. Validação da Regra de Negócio (Idade Mínima)
        let idadeMinima = 0;
        if (cargo === "Presidente" || cargo === "Senador") {
            idadeMinima = 35;
        } else if (cargo === "Governador") {
            idadeMinima = 30;
        } else if (cargo === "Deputado Federal" || cargo === "Deputado Estadual") {
            idadeMinima = 21;
        }

        if (candidato.idade < idadeMinima) {
            return res.send(`<script>alert("Idade insuficiente! A Constituição exige a idade mínima de ${idadeMinima} anos para o cargo de ${cargo}. Sua idade atual é ${candidato.idade} anos."); window.history.back();</script>`);
        }

        // 3. Validação de Número Único
        const numeroEmUso = await Candidato.findOne({ numero: Number(numero), cargo: cargo });
        if (numeroEmUso) {
            return res.send(`<script>alert("Esse número já está registrado para este cargo!"); window.history.back();</script>`);
        }

        // 4. Salva a Candidatura
        await Candidato.findByIdAndUpdate(idUsuario, {
            numero: Number(numero),
            cargo,
            partido,
            slogan,
            descricao,
            status: "Pendente"
        });

        res.send(`<script>alert("Candidatura lançada com sucesso! Aguarde a homologação do administrador."); window.location.href="/minha_candidatura";</script>`);

    } catch (error) {
        console.error("Erro ao lançar candidatura:", error);
        res.status(500).send(`<script>alert("Erro ao lançar candidatura."); window.history.back();</script>`);
    }
});

app.get("/perfil", async (req, res) => {
    try {
        const idUsuario = req.session.id_usuario;
        const tipoAcesso = req.session.tipoAcesso;

        if (!idUsuario || tipoAcesso === 'Administrador') {
            return res.redirect(res.locals.linkHome);
        }

        let usuario;
        if (tipoAcesso === 'Eleitor') {
            usuario = await Eleitor.findById(idUsuario);
        } else if (tipoAcesso === 'Candidato') {
            usuario = await Candidato.findById(idUsuario);
        }

        res.render("perfil.ejs", { usuario, tipoAcesso });
    } catch (error) {
        console.error("Erro ao carregar perfil:", error);
        res.status(500).send("Erro interno ao carregar o perfil.");
    }
});

app.post("/perfil/editar", async (req, res) => {
    try {
        const idUsuario = req.session.id_usuario;
        const tipoAcesso = req.session.tipoAcesso;
        const { nome, dataNascimento, estado, cidade } = req.body;

        if (!idUsuario || tipoAcesso === 'Administrador') {
            return res.redirect("/login");
        }

        const hoje = new Date();
        const nascimento = new Date(dataNascimento);
        let idadedecalculo = hoje.getFullYear() - nascimento.getFullYear();
        const m = hoje.getMonth() - nascimento.getMonth();
        if (m < 0 || (m === 0 && hoje.getDate() < nascimento.getDate())) {
            idadedecalculo--;
        }

        let Modelo = tipoAcesso === 'Eleitor' ? Eleitor : Candidato;

        await Modelo.findByIdAndUpdate(idUsuario, {
            nome,
            dataNascimento,
            idade: idadedecalculo,
            estado,
            cidade
        });

        res.send(`
            <script>
                alert('Dados updated com sucesso!');
                window.location.href = "/perfil";
            </script>
        `);
    } catch (error) {
        console.error("Erro ao atualizar perfil:", error);
        res.status(500).send("Erro ao salvar as alterações.");
    }
});

app.get("/consulta_candidatos", async (req, res) => {
    try {
        if (!req.session.id_usuario) {
            return res.redirect('/login');
        }

        const candidatos = await Candidato.find({}).sort({ nome: 1 });

        const candidatosPorCargo = {};
        candidatos.forEach(candidato => {
            const cargoAtual = candidato.cargo ? candidato.cargo : "Sem Cargo Definido";
            
            if (!candidatosPorCargo[cargoAtual]) {
                candidatosPorCargo[cargoAtual] = [];
            }
            candidatosPorCargo[cargoAtual].push(candidato);
        });

        res.render("consulta_candidatos.ejs", { candidatosPorCargo });
    } catch (error) {
        res.status(500).send("Erro ao carregar a lista de candidatos.");
    }
});

app.post("/candidatos/:id/editar", async (req, res) => {
    try {
        if (req.session.tipoAcesso !== 'Administrador') {
            return res.redirect('/');
        }

        // Recebendo cidade e estado no lugar de municipio
        const { nome, partido, cidade, estado, numero, status } = req.body;
        
        await Candidato.findByIdAndUpdate(req.params.id, {
            nome,
            partido,
            cidade,
            estado,
            numero: Number(numero),
            status
        });

        res.redirect("/consulta_candidatos");
    } catch (error) {
        res.status(500).send("Erro ao editar candidato.");
    }
});

app.post("/candidatos/:id/inativar", async (req, res) => {
    try {
        if (req.session.tipoAcesso !== 'Administrador') {
            return res.redirect('/');
        }

        // Busca o candidato para saber se ele está ativo ou inativo
        const candidato = await Candidato.findById(req.params.id);
        
        // Inverte o status atual (Se true vira false, se false vira true)
        await Candidato.findByIdAndUpdate(req.params.id, { ativo: !candidato.ativo });
        
        res.redirect("/consulta_candidatos");
    } catch (error) {
        res.status(500).send("Erro ao alterar status do cadastro.");
    }
});

app.get("/admin", async (req, res) => {
    try {
        if (req.session.tipoAcesso !== 'Administrador') {
            return res.redirect('/login');
        }

        const docs = await Candidato.find({});
        res.render("admin.ejs", { Candidatos: docs });
        
    } catch (error) {
        res.status(500).send("Ocorreu um erro ao carregar os candidatos.");
    }
});

app.get("/consulta_eleitores", async (req, res) => {
    try {
        if (req.session.tipoAcesso !== 'Administrador') {
            return res.redirect('/login');
        }

        const eleitores = await Eleitor.find({}).sort({ nome: 1 });
        res.render("consulta_eleitores.ejs", { Eleitores: eleitores });
    } catch (error) {
        res.status(500).send("Erro ao carregar a lista de eleitores.");
    }
});

app.post("/eleitores/:id/editar", async (req, res) => {
    try {
        if (req.session.tipoAcesso !== 'Administrador') {
            return res.redirect('/');
        }

        const { nome, dataNascimento, cidade, estado } = req.body;
        
        // Recalcular a idade baseada na nova data inserida
        const hoje = new Date();
        const nascimento = new Date(dataNascimento);
        let idadeCalculada = hoje.getFullYear() - nascimento.getFullYear();
        const m = hoje.getMonth() - nascimento.getMonth();
        if (m < 0 || (m === 0 && hoje.getDate() < nascimento.getDate())) {
            idadeCalculada--;
        }

        await Eleitor.findByIdAndUpdate(req.params.id, {
            nome,
            dataNascimento,
            idade: idadeCalculada,
            cidade,
            estado
        });

        res.redirect("/consulta_eleitores");
    } catch (error) {
        res.status(500).send("Erro ao editar eleitor.");
    }
});

app.post("/eleitores/:id/inativar", async (req, res) => {
    try {
        if (req.session.tipoAcesso !== 'Administrador') {
            return res.redirect('/');
        }

        const eleitor = await Eleitor.findById(req.params.id);
        await Eleitor.findByIdAndUpdate(req.params.id, { ativo: !eleitor.ativo });
        
        res.redirect("/consulta_eleitores");
    } catch (error) {
        res.status(500).send("Erro ao alterar status do eleitor.");
    }
});

app.listen("3000", function () {
  console.log("Servidor rodando na porta 3000!");
});